import './HomeStyle.css';
function HomePage(){
    return(
        <div className='BodyHome'>
            <div>
  <div style={{ height: '150px' }} />
  <div style={{ height: "100%", width: "100%" }}>
    <h2
        style={{
          margin: '20px',
          fontFamily: "monospace",
          fontSize: '82px',
          paddingTop: '5px',
          paddingLeft: '5px'
        }}
      >
        Products
      </h2>
    <div
      style={{
        backgroundColor:'white',
        margin:'0px 40px',
        height:'500px',
        display:'flex',
        padding:'40px'
      }}>
        <div className='prods'>
          <h2>Title</h2>
          <div style={{
            backgroundColor:'#6f6f6f',
            width:'300px',
            height:'300px'
          }}></div>
          <h2>Price</h2>
          <span style={{
            margin:'5px'
          }}>Product Description, Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sequi quod iste nesciunt doloribus odio enim impedit magnam sit nam sapiente. Repellendus praesentium itaque iusto sit minima pariatur doloribus, corporis illo!</span>
          <h3>Rating: X X X X X stars y responeses</h3>
         </div>

    </div>
  </div>
</div>

        </div>
    )
}

export default HomePage;